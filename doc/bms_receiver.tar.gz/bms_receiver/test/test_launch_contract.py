from pathlib import Path


LAUNCH_FILE = (
    Path(__file__).resolve().parents[2]
    / "turn_on_ox_robot"
    / "launch"
    / "turn_on_ox_robot.launch.py"
)
NODE_FILE = Path(__file__).resolve().parents[1] / "bms_receiver" / "node.py"


def test_bringup_uses_controller_bms_receiver():
    text = LAUNCH_FILE.read_text(encoding="utf-8")

    assert 'package="bms_receiver"' in text
    assert 'executable="bms_receiver_node"' in text
    assert 'executable="read_powervol"' not in text
    assert '"byte_order": "big"' in text
    assert '"comm_ok_value": 1' in text


def test_runtime_parameters_are_refreshed_without_service_restart():
    text = NODE_FILE.read_text(encoding="utf-8")

    assert text.count('self.get_parameter("byte_order").value') >= 2
    assert text.count('self.get_parameter("comm_ok_value").value') >= 2
